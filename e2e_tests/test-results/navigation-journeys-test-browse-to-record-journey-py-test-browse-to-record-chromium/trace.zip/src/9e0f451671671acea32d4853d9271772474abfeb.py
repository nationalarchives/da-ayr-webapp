import os
import re
import uuid

import keycloak
import pytest
from playwright.sync_api import Page, expect


def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line(
        "markers", "health_check: Health check tests for monitoring"
    )


class Utils:
    @staticmethod
    def get_desktop_page_table_headers(page: Page):
        return page.locator(
            "th:not(.govuk-table--invisible-on-desktop)"
        ).evaluate_all("""els => els.map(e => e.innerText.trim())""")

    @staticmethod
    def get_desktop_page_table_rows(page: Page):
        return page.get_by_role("row").evaluate_all(
            """els => {
                    document.querySelectorAll('.govuk-table--invisible-on-desktop')
                        .forEach(el => el.remove())
                    return els.map(el =>
                        [...el.querySelectorAll('td')].map(e => e.innerText.trim())
                    ).filter(e => e.length > 0)
                }
            """
        )

    def get_desktop_page_transferring_body_table_headers(page: Page):
        return page.locator(
            "th:not(.govuk-table--invisible-on-desktop)"
        ).evaluate_all(
            """
            els => els
                .map(e => e.innerText.trim())
                .filter(text => text === 'Found within' || text === 'Search results')
        """
        )

    def get_desktop_page_transferring_body_inner_table_headers(page: Page):
        return page.locator(
            "th:not(.govuk-table--invisible-on-desktop)"
        ).evaluate_all(
            """
            els => els
                .map(e => e.innerText.trim())
                .filter(text => text !== 'Found within' && text !== 'Search results')
        """
        )

    def get_desktop_page_table_metadata(page: Page):
        return page.locator("tbody tbody").evaluate_all(
            """rows => rows.map(row =>
        Array.from(row.querySelectorAll('.govuk-table__cell')).map(cell => cell.innerText.trim())
    )"""
        )


@pytest.fixture
def utils():
    return Utils


@pytest.fixture
def page(page, request) -> Page:
    page.context.set_default_timeout(15000)
    if "test_css_" not in request.node.name and callable(request.node.obj):

        def route_intercept(route):
            if route.request.resource_type == "stylesheet":
                return route.abort()
            return route.continue_()

        page.route("**/*", route_intercept)

    return page


@pytest.fixture
def create_user_page(
    page,
) -> Page:  # FIXME: browser_name specified until https://github.com/microsoft/playwright-pytest/issues/172 fixed
    # so that multiple browser flags in cli are honoured
    def _create_user_page(username, password) -> Page:
        page.goto("/sign-in")

        expect(page.locator("input[type='password']")).to_be_visible(
            timeout=10000
        )

        username_input = _get_username_input_or_none(page)
        if username_input is None:
            raise AssertionError(
                "Could not find username/email input on sign-in page"
            )

        password_input = _get_password_input(page)
        submit_button = _get_submit_button(page)

        username_input.fill(username)
        password_input.fill(password)
        submit_button.click()
        expect(page).to_have_url(re.compile(r".*/browse.*"), timeout=10000)

        return page

    return _create_user_page


def _get_username_input_or_none(page: Page):
    if page.locator("label:has-text('Email address')").count() > 0:
        return page.get_by_label("Email address").first
    if page.locator("label:has-text('Email')").count() > 0:
        return page.get_by_label("Email").first
    if page.locator("label:has-text('Username or email')").count() > 0:
        return page.get_by_label("Username or email").first

    username_inputs = page.locator(
        "input[name='username'], input[name='email'], input#username"
    )
    if username_inputs.count() == 0:
        return None
    return username_inputs.first


def _get_password_input(page: Page):
    if page.get_by_role("textbox", name="Password").count() > 0:
        return page.get_by_role("textbox", name="Password").first
    return page.locator("input[type='password']").first


def _get_submit_button(page: Page):
    if page.get_by_role("button", name="Sign in").count() > 0:
        return page.get_by_role("button", name="Sign in").first
    return page.locator("button[type='submit'], input[type='submit']").first


def get_keycloak_token(keycloak_openid):
    """Get a fresh token from Keycloak."""
    return keycloak_openid.token(grant_type="client_credentials")


def refresh_keycloak_admin_token(keycloak_admin_instance, keycloak_openid):
    """Refresh the token on a KeycloakAdmin instance."""
    token = get_keycloak_token(keycloak_openid)
    keycloak_admin_instance.token = token
    return keycloak_admin_instance


@pytest.fixture(scope="session")
def keycloak_openid_client():
    """Create a reusable KeycloakOpenID client for token operations."""
    realm_name = os.environ.get("KEYCLOAK_REALM_NAME")
    client_id = os.environ.get("KEYCLOAK_CLIENT_ID")
    client_secret = os.environ.get("KEYCLOAK_CLIENT_SECRET")
    server_url = os.environ.get("KEYCLOAK_BASE_URI")

    return keycloak.KeycloakOpenID(
        server_url=server_url,
        client_id=client_id,
        realm_name=realm_name,
        client_secret_key=client_secret,
        verify=False,
    )


@pytest.fixture(scope="session")
def keycloak_admin(keycloak_openid_client):
    realm_name = os.environ.get("KEYCLOAK_REALM_NAME")
    server_url = os.environ.get("KEYCLOAK_BASE_URI")

    token = get_keycloak_token(keycloak_openid_client)
    keycloak_admin = keycloak.KeycloakAdmin(
        server_url=server_url,
        realm_name=realm_name,
        token=token,
    )
    return keycloak_admin


@pytest.fixture(scope="session")
def create_keycloak_user(keycloak_admin):
    def _create_keycloak_user(groups, user_type):
        user_email = f"{uuid.uuid4().hex}{user_type}@test.com"
        user_pass = uuid.uuid4().hex
        user_first_name = "Test"
        user_last_name = "Name"
        user_id = keycloak_admin.create_user(
            {
                "firstName": user_first_name,
                "lastName": user_last_name,
                "username": user_email,
                "email": user_email,
                "enabled": True,
                "groups": groups,
                "credentials": [{"value": user_pass, "type": "password"}],
            }
        )
        return user_id, user_email, user_pass

    return _create_keycloak_user


@pytest.fixture(scope="session")
def create_aau_keycloak_user(
    keycloak_admin, keycloak_openid_client, create_keycloak_user
):
    user_groups = ["/ayr_user_type/view_all"]
    user_type = "aau"
    user_id, user_email, user_pass = create_keycloak_user(
        user_groups, user_type
    )

    yield user_email, user_pass

    refresh_keycloak_admin_token(keycloak_admin, keycloak_openid_client)
    keycloak_admin.delete_user(user_id=user_id)


@pytest.fixture(scope="session")
def create_standard_keycloak_user(
    keycloak_admin, keycloak_openid_client, create_keycloak_user
):
    user_groups = [
        "/ayr_user_type/view_dept",
        "/transferring_body_user/Testing A",
    ]
    user_type = "standard"
    user_id, user_email, user_pass = create_keycloak_user(
        user_groups, user_type
    )

    yield user_email, user_pass

    refresh_keycloak_admin_token(keycloak_admin, keycloak_openid_client)
    keycloak_admin.delete_user(user_id=user_id)


@pytest.fixture(scope="session")
def create_aau_keycloak_user_with_download(
    keycloak_admin, keycloak_openid_client, create_keycloak_user
):
    user_groups = ["/ayr_user_type/view_all", "/ayr_user_type/download"]
    user_type = "aau"
    user_id, user_email, user_pass = create_keycloak_user(
        user_groups, user_type
    )

    yield user_email, user_pass

    refresh_keycloak_admin_token(keycloak_admin, keycloak_openid_client)
    keycloak_admin.delete_user(user_id=user_id)


@pytest.fixture(scope="session")
def create_standard_keycloak_user_with_download(
    keycloak_admin, keycloak_openid_client, create_keycloak_user
):
    user_groups = [
        "/ayr_user_type/view_dept",
        "/ayr_user_type/download",
        "/transferring_body_user/Testing A",
    ]
    user_type = "standard"
    user_id, user_email, user_pass = create_keycloak_user(
        user_groups, user_type
    )

    yield user_email, user_pass

    refresh_keycloak_admin_token(keycloak_admin, keycloak_openid_client)
    keycloak_admin.delete_user(user_id=user_id)


@pytest.fixture
def aau_user_page(create_user_page, create_aau_keycloak_user) -> Page:
    username, password = create_aau_keycloak_user
    page = create_user_page(username, password)
    yield page
    page.goto("/sign-out")


@pytest.fixture
def standard_user_page(create_user_page, create_standard_keycloak_user) -> Page:
    username, password = create_standard_keycloak_user
    page = create_user_page(username, password)
    yield page
    page.goto("/sign-out")


@pytest.fixture
def aau_user_page_with_download(
    create_user_page, create_aau_keycloak_user_with_download
) -> Page:
    username, password = create_aau_keycloak_user_with_download
    page = create_user_page(username, password)
    yield page
    page.goto("/sign-out")


@pytest.fixture
def standard_user_page_with_download(
    create_user_page, create_standard_keycloak_user_with_download
) -> Page:
    username, password = create_standard_keycloak_user_with_download
    page = create_user_page(username, password)
    yield page
    page.goto("/sign-out")


@pytest.fixture
def browser_context_args(browser_context_args, browser_name):
    """
    Fixture for configuring Playwright browser context arguments.
    This fixture is used to customize browser context arguments for Playwright
    browser instances. It sets the 'ignore_https_errors' option to True, which
    allows ignoring HTTPS errors, To disable JS set 'java_script_enabled' to False, which
    disables JavaScript in the browser context.
    Parameters:
        browser_context_args (dict): The default browser context arguments.
    Returns:
        dict: Updated browser context arguments with customized settings.
    """
    context_args = {
        **browser_context_args,
        "ignore_https_errors": True,
        # WebKit intermittently lands on Keycloak auth transitions
        # that require JavaScript to render/login correctly.
        "java_script_enabled": browser_name == "webkit",
    }

    if browser_name != "webkit":
        context_args["user_agent"] = (
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/114.0.0.0 Safari/537.36"
        )

    return context_args
